package uk.ac.mmu.advprog.programmingassignment2;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Map;

import javax.net.ssl.HttpsURLConnection;

public class EditVehicle extends AppCompatActivity
{
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_vehicle);//Set the view to the activity_edit_vehicles.xml stored in the layout folder

        //Passing in vehicle details
        Bundle extras = getIntent().getExtras();
        Vehicle allVehicle = (Vehicle) extras.get("edit");

        //Assign variables to the edit text boxes (INPUT BOXES)
        final EditText VehicleIDTxt = findViewById(R.id.VehicleIDTxt);
        final EditText MakeTxt = findViewById(R.id.MakeTxt);
        final EditText ModelTxt = findViewById(R.id.ModelTxt);
        final EditText YearTxt = findViewById(R.id.YearTxt);
        final EditText PriceTxt = findViewById(R.id.PriceTxt);
        final EditText LicenseNumberTxt = findViewById(R.id.LicenseNumberTxt);
        final EditText ColourTxt = findViewById(R.id.ColourTxt);
        final EditText NumberDoorsTxt = findViewById(R.id.NumberDoorsTxt);
        final EditText TransmissionTxt = findViewById(R.id.TransmissionTxt);
        final EditText MileageTxt = findViewById(R.id.MileageTxt);
        final EditText FuelTypeTxt = findViewById(R.id.FuelTypeTxt);
        final EditText EngineSizeTxt = findViewById(R.id.EngineSizeTxt);
        final EditText BodyStyleTxt = findViewById(R.id.BodyStyleTxt);
        final EditText ConditionTxt = findViewById(R.id.ConditionTxt);
        final EditText NotesTxt = findViewById(R.id.NotesTxt);

        //Setting Text Boxes with filled in values
        VehicleIDTxt.setText(Integer.toString(allVehicle.getVehicle_id()));
        MakeTxt.setText(allVehicle.getMake());
        ModelTxt.setText(allVehicle.getModel());
        YearTxt.setText(Integer.toString(allVehicle.getYear()));
        PriceTxt.setText(Integer.toString(allVehicle.getPrice()));
        LicenseNumberTxt.setText(allVehicle.getLicense_number());
        ColourTxt.setText(allVehicle.getColour());
        NumberDoorsTxt.setText(Integer.toString(allVehicle.getNumber_doors()));
        TransmissionTxt.setText(allVehicle.getTransmission());
        MileageTxt.setText(Integer.toString(allVehicle.getMileage()));
        FuelTypeTxt.setText(allVehicle.getFuel_type());
        EngineSizeTxt.setText(Integer.toString(allVehicle.getEngine_size()));
        BodyStyleTxt.setText(allVehicle.getBody_style());
        ConditionTxt.setText(allVehicle.getCondition());
        NotesTxt.setText(allVehicle.getNotes());

        //Find the update button by the ID and set it to the name UpdateVehicleBtn
        Button UpdateVehicleBtnVehicleBtn = findViewById(R.id.UpdateVehicleBtn);

        final HashMap<String, String> params = new HashMap<>();
        UpdateVehicleBtnVehicleBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v)
            {
                //Setting the paramters to be passed through
                params.put("vehicle_id", VehicleIDTxt.getText().toString());
                params.put("make", MakeTxt.getText().toString());
                params.put("model", ModelTxt.getText().toString());
                params.put("year", YearTxt.getText().toString());
                params.put("price", PriceTxt.getText().toString());
                params.put("license_number", LicenseNumberTxt.getText().toString());
                params.put("colour", ColourTxt.getText().toString());
                params.put("number_doors", NumberDoorsTxt.getText().toString());
                params.put("transmission", TransmissionTxt.getText().toString());
                params.put("mileage", MileageTxt.getText().toString());
                params.put("fuel_type", FuelTypeTxt.getText().toString());
                params.put("engine_size", EngineSizeTxt.getText().toString());
                params.put("body_style", BodyStyleTxt.getText().toString());
                params.put("condition", ConditionTxt.getText().toString());
                params.put("notes", NotesTxt.getText().toString());

                String url = "http://10.0.2.2:8005/vehicles/api";
                PerformPutCall(url, params); //Make a put call using the url and paramaters
            }
        });
    }

    //UPDATE / PUT CALL
    public String PerformPutCall(String requestURL, HashMap<String, String> postDataParams)
    {
        URL url;
        String response = "";
        try {
            url = new URL(requestURL);

            //Create the connection object
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setReadTimeout(15000);
            conn.setConnectTimeout(15000);
            conn.setRequestMethod("PUT");
            conn.setDoInput(true);
            conn.setDoOutput(true);

            //Write/send/POST dara to the connection using output stream and buffered writer
            OutputStream os = conn.getOutputStream();
            BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(os, "UTF-8"));

            //Write/send/Post key/value data (url encoded) to the server
            writer.write(getPutDataString(postDataParams));

            //clear the writer
            writer.flush();
            writer.close();

            //close the output stream
            os.close();

            //get the server response code to determine what to do next (ie success/error)
            int responseCode = conn.getResponseCode();
            System.out.println("Response code = " + responseCode);

            if (responseCode == HttpsURLConnection.HTTP_OK) {
                Toast.makeText(this, "Vehicle Updated", Toast.LENGTH_LONG).show();
                String line;
                BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                while ((line = br.readLine()) != null) {
                    response += line;
                }

                Intent Return = new Intent(EditVehicle.this, MainActivity.class);
                EditVehicle.this.startActivity(Return);

            } else {
                Toast.makeText(this, "Error failed to update Vehicle", Toast.LENGTH_LONG).show();
                response = "";
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        System.out.println("response = " + response);
        return response;
    }

    //This method converts a hashmap to a URL query string of key/valuse pairs
    private String getPutDataString(HashMap<String, String> params) throws UnsupportedEncodingException
    {
        StringBuilder result = new StringBuilder();
        boolean first = true;
        for (Map.Entry<String, String> entry : params.entrySet())
        {
            if (first)
            {
                first = false;
            }
            else
            {
              result.append("&");
            }

            result.append(URLEncoder.encode(entry.getKey(), "UTF-8"));
            result.append("=");
            result.append(URLEncoder.encode(entry.getValue(), "UTF-8"));
        }
        return result.toString();
    }
}