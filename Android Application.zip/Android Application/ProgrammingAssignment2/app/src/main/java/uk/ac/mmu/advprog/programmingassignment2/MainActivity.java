package uk.ac.mmu.advprog.programmingassignment2;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.StrictMode;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONException;
import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static android.app.PendingIntent.getActivity;
import static android.support.v4.content.ContextCompat.startActivity;
import static java.lang.System.in;

public class MainActivity extends AppCompatActivity
{
    String[] Model;
    String[] Make;
    Integer[] Year;
    String[] LicenseNumber;
    Integer[] ID;
    List<Map<String, String>> data = new ArrayList<>();    //List View Main Activity Dara Array
    ArrayList<Vehicle> allVehicle = new ArrayList<>();    //Array List View Storing All Information about Vehicle

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main); //Use the XML of activity_main in the layout folder

        //Run Network Calls On Main Thread
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);

        //Make a HTTP Call
        HttpURLConnection urlConnection;
        InputStream in = null;
        try
        {
            URL url = new URL("http://10.0.2.2:8005/vehicles/api"); // URL which we are connecting to
            urlConnection = (HttpURLConnection) url.openConnection(); // Open the connection to the specified URL
            in = new BufferedInputStream(urlConnection.getInputStream());  // Get the response from the server in an input stream
        }
        catch (IOException e) //IOException Catch Block (Exception Handler)
        {
            e.printStackTrace();
        }
        String response = convertStreamToString(in); // Covert the input stream to a string
        System.out.println("Server response = " + response);

        try
        {
                //JSON Array passing the string response from the server, converting the string into a JSON array
                JSONArray jsonArray = new JSONArray(response);

                //Initialising Arrays and set the size of these to the ammount of objects returned by the server
                Make = new String[jsonArray.length()];
                Model = new String[jsonArray.length()];
                Year = new Integer[jsonArray.length()];
                LicenseNumber = new String[jsonArray.length()];
                ID = new Integer[jsonArray.length()];

                //For loop to iterate over the JSON array
                for (int i = 0; i < jsonArray.length(); i++)
                {
                    final Integer vehicle_id = jsonArray.getJSONObject(i).getInt("vehicle_id");
                    String make = jsonArray.getJSONObject(i).get("make").toString();
                    String model = jsonArray.getJSONObject(i).get("model").toString();
                    Integer year = jsonArray.getJSONObject(i).getInt("year");
                    Integer price = jsonArray.getJSONObject(i).getInt("price");
                    String license_number = jsonArray.getJSONObject(i).get("license_number").toString();
                    String Colour = jsonArray.getJSONObject(i).get("colour").toString();
                    Integer number_doors = jsonArray.getJSONObject(i).getInt("number_doors");
                    String transmission = jsonArray.getJSONObject(i).get("transmission").toString();
                    Integer mileage = jsonArray.getJSONObject(i).getInt("mileage");
                    String fuel_type = jsonArray.getJSONObject(i).get("fuel_type").toString();
                    Integer engine_size = jsonArray.getJSONObject(i).getInt("engine_size");
                    String body_style = jsonArray.getJSONObject(i).get("body_style").toString();
                    String condition = jsonArray.getJSONObject(i).get("condition").toString();
                    String notes = jsonArray.getJSONObject(i).get("notes").toString();

                    Make[i] = make;
                    Model[i] = model;
                    Year[i] = year;
                    ID[i] = vehicle_id;
                    LicenseNumber[i] = license_number;

                    //Formatting String
                    String MMY = String.format("%s %s (%s)", make, model, year);

                    //Adapter Data For List View
                    Map<String, String> datum = new HashMap<>();
                    datum.put("Make_Model_Year", MMY);
                    datum.put("License Number", license_number);
                    data.add(datum);

                    //Getting List View by ID
                    ListView VehicleList = findViewById(R.id.VehicleListView);

                    //Setting the Adapter with data to use in the list view
                    SimpleAdapter adapter = new SimpleAdapter(getApplicationContext(), data, android.R.layout.simple_list_item_2, new String[]{"Make_Model_Year", "License Number"}, new int[]{android.R.id.text1, android.R.id.text2})
                    {
                        //Changing the colour of the text to a custom blue colour.
                        public View getView(int position, View convertView, ViewGroup parent)
                        {
                            View view = super.getView(position, convertView, parent);
                            TextView text1 = view.findViewById(android.R.id.text1);
                            text1.setTextColor(Color.rgb(20, 25, 70));
                            TextView text2 = view.findViewById(android.R.id.text2);
                            text2.setTextColor(Color.rgb(20, 25, 70));
                            return view;
                        }
                    };

                    VehicleList.setAdapter(adapter); //Setting the List view to use the adapter

                    //Adding all JSON get files to allVehicles Array List
                    Vehicle in1 = new Vehicle(vehicle_id, make, model, year, price, license_number, Colour, number_doors, transmission, mileage, fuel_type, engine_size, body_style, condition, notes);
                    allVehicle.add(in1);

                    //When an item in list view is clicked
                    VehicleList.setOnItemClickListener(new AdapterView.OnItemClickListener()
                    {
                        @Override
                        public void onItemClick(AdapterView<?> adapterView, View view, int i, long l)
                        {
                            Toast.makeText(MainActivity.this, "You Clicked The Vehicle With The License Number Of: " + allVehicle.get(i).getLicense_number(), Toast.LENGTH_SHORT).show(); //Show Message On Screen
                            Intent intent = new Intent(MainActivity.this, VehicleDetails.class); //Take the user from the main activity to the vehicle details activity
                            intent.putExtra("vehicle", allVehicle.get(i)); //Pass through the allvehicle array
                            startActivity(intent); //Start the intent
                        }
                    });

                    //When an item in the list view is clicked for a long period
                    VehicleList.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener()
                    {
                        @Override
                        public boolean onItemLongClick(AdapterView<?> adapterView, View view, final int i, long l)
                        {
                            AlertDialog.Builder builder1 = new AlertDialog.Builder(MainActivity.this); //Make a new Dialog box for this activity
                            builder1.setMessage("Do You Wish To Delete This Vehicle?"); //Message displayed on the dialog box
                            builder1.setCancelable(true); //Setting it so you can cancel the dialog box if opened by mistake

                            builder1.setPositiveButton("Cancel", new DialogInterface.OnClickListener() //Set Right button to say Cancel
                            {
                                public void onClick(DialogInterface dialog, int id)
                                {
                                    dialog.cancel(); //When you click cancel it will cancel out the dialog box (Close it)
                                }
                            });

                            builder1.setNegativeButton("Yes", new DialogInterface.OnClickListener() //Set Left button to say Yes
                            {
                                public void onClick(DialogInterface dialog, int id)
                                {
                                    Integer ID = allVehicle.get(i).getVehicle_id(); //Get the ID of the vehicle which we clicked on
                                    String url = "http://10.0.2.2:8005/vehicles/api?vehicle_id=" + ID; //Set the url + the id of the vehicle we clicked on
                                    System.out.println(ID); //Print in logcat/console the ID
                                    System.out.println(url); //Print in logcat/console the url
                                    performDelteCall(url); //Perform a delete call using the url
                                }
                            });

                            AlertDialog DialogBox = builder1.create(); //Create dialog box
                            DialogBox.show(); //Show dialog box

                            return false;

                        }//END OF ON ITEM LONG CLICK
                    }); //END OF SET ON ITEM LONG CLICK LISTENER
                } //END OF FOR LOOP
        }  //END OF TRY

        catch (JSONException e)
        {
            e.printStackTrace();
        }
    }// END OF ON CREATE

        public String convertStreamToString(InputStream is)
        {
        java.util.Scanner s = new java.util.Scanner(is).useDelimiter("\\A");
        return s.hasNext() ? s.next() : "";
        }


    //MAKING AN ACTION BAR (TOOLBAR) BUTTON
    @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {
        getMenuInflater().inflate(R.menu.newvehiclebuttonmenu, menu); //Get the new menu button
        return super.onCreateOptionsMenu(menu);
    }

    //TOOLBAR BUTTON ON CLICK
    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        int createbtn = item.getItemId();

        if (createbtn == R.id.createbtn)
        {
            //TAKE USER TO NEW VEHICLE PAGE
            Intent myIntent = new Intent(MainActivity.this, AddVehicle.class); //Take the user from the main acitivity to the add vehicle class when the new menu button is clicked
            MainActivity.this.startActivity(myIntent);
        }
        return super.onOptionsItemSelected(item);
    }

    //Make a DELETE call using the URL
    public String performDelteCall(String requestURL)
    {
        URL url;
        String Response = " ";
        String delete;
        try {
            url = new URL(requestURL);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setReadTimeout(15000);
            conn.setConnectTimeout(15000);
            //  conn.setRequestProperty("X-HTTP-Method-Override","DELETE");
            conn.setRequestMethod("DELETE");
            conn.setDoInput(true);
            conn.setDoOutput(true);

            OutputStream os = conn.getOutputStream();
            BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(os, "UTF-8"));

            // writer.write(url);
            writer.flush();
            writer.flush();
            os.close();

            int responseCode = conn.getResponseCode();
            System.out.println("response code " + responseCode);

            if (responseCode == HttpURLConnection.HTTP_OK) {
                Toast.makeText(this, "Vehicle Deleted", Toast.LENGTH_LONG).show();
                String line;
                BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                while ((line = br.readLine()) != null) {
                    Response += line;
                }
            } else {
                Toast.makeText(this, "error failed to delete vehicle", Toast.LENGTH_LONG).show();
                Response = " ";
            }


        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        } catch (ProtocolException e) {
            e.printStackTrace();
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        System.out.println("response= " + Response);
        return Response;
    }
}




