package uk.ac.mmu.advprog.programmingassignment2;
import android.os.Bundle;
import android.os.health.SystemHealthManager;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.content.Intent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import javax.net.ssl.HttpsURLConnection;

public class VehicleDetails extends AppCompatActivity
{
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.vehicledetails); //Set the view to the vehicledetails.xml stored in the layout folder

        //Passing in vehicle details
        Bundle extras = getIntent().getExtras();
        final Vehicle allVehicle = (Vehicle) extras.get("vehicle");

        //Finding edit text boxes by ID
        final EditText VehicleIDTxt = findViewById(R.id.VehicleIDTxt);
        EditText MakeTxt = findViewById(R.id.MakeTxt);
        EditText ModelTxt = findViewById(R.id.ModelTxt);
        EditText YearTxt = findViewById(R.id.YearTxt);
        EditText PriceTxt = findViewById(R.id.PriceTxt);
        EditText LicenseNumberTxt = findViewById(R.id.LicenseNumberTxt);
        EditText ColourTxt = findViewById(R.id.ColourTxt);
        EditText NumberDoorsTxt = findViewById(R.id.NumberDoorsTxt);
        EditText TransmissionTxt = findViewById(R.id.TransmissionTxt);
        EditText MileageTxt = findViewById(R.id.MileageTxt);
        EditText FuelTypeTxt = findViewById(R.id.FuelTypeTxt);
        EditText EngineSizeTxt = findViewById(R.id.EngineSizeTxt);
        EditText BodyStyleTxt = findViewById(R.id.BodyStyleTxt);
        EditText ConditionTxt = findViewById(R.id.ConditionTxt);
        EditText NotesTxt = findViewById(R.id.NotesTxt);

        //Setting Text Boxes with filled in values and setting them not editable
        VehicleIDTxt.setText(Integer.toString(allVehicle.getVehicle_id()));VehicleIDTxt.setFocusable(false);
        MakeTxt.setText(allVehicle.getMake());MakeTxt.setFocusable(false);
        ModelTxt.setText(allVehicle.getModel());ModelTxt.setFocusable(false);
        YearTxt.setText(Integer.toString(allVehicle.getYear()));YearTxt.setFocusable(false);
        PriceTxt.setText(Integer.toString(allVehicle.getPrice()));PriceTxt.setFocusable(false);
        LicenseNumberTxt.setText(allVehicle.getLicense_number());LicenseNumberTxt.setFocusable(false);
        ColourTxt.setText(allVehicle.getColour());ColourTxt.setFocusable(false);
        NumberDoorsTxt.setText(Integer.toString(allVehicle.getNumber_doors()));NumberDoorsTxt.setFocusable(false);
        TransmissionTxt.setText(allVehicle.getTransmission());TransmissionTxt.setFocusable(false);
        MileageTxt.setText(Integer.toString(allVehicle.getMileage()));MileageTxt.setFocusable(false);
        FuelTypeTxt.setText(allVehicle.getFuel_type());FuelTypeTxt.setFocusable(false);
        EngineSizeTxt.setText(Integer.toString(allVehicle.getEngine_size()));EngineSizeTxt.setFocusable(false);
        BodyStyleTxt.setText(allVehicle.getBody_style());BodyStyleTxt.setFocusable(false);
        ConditionTxt.setText(allVehicle.getCondition());ConditionTxt.setFocusable(false);
        NotesTxt.setText(allVehicle.getNotes());NotesTxt.setFocusable(false);

        //Find the edit button by the ID and set it to the name EditVehicle
        Button EditVehicle = findViewById(R.id.EditBtn);

        EditVehicle.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                //When edit button is clicked on send user to the edit vehicle details page and pass through the allvehicle array
                Intent intent = new Intent(getApplicationContext(), EditVehicle.class);
                intent.putExtra("edit", allVehicle);
                startActivity(intent);
            }
        });

        //Find the delete button by the ID and set it to the name DeleteButton
        Button DeleteButton = findViewById(R.id.DeleteBtn);

        DeleteButton.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                Integer ID = allVehicle.getVehicle_id(); //Get the ID of the vehicle
                String url = "http://10.0.2.2:8005/vehicles/api?vehicle_id=" + ID; //Set the url + the id of the vehicle we clicked on
                System.out.println(ID); //Print in logcat/console the ID
                System.out.println(url); //Print in logcat/console the url
                performDelteCall(url); //Perform a delete call using the url
            }
        });
    }

    //Perform Delete Call
    public String performDelteCall(String requestURL)
    {
        URL url;
        String Response= " ";
        String delete ;
        try
        {
            url = new URL(requestURL);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setReadTimeout(15000);
            conn.setConnectTimeout(15000);
            //  conn.setRequestProperty("X-HTTP-Method-Override","DELETE");
            conn.setRequestMethod("DELETE");
            conn.setDoInput(true);
            conn.setDoOutput(true);

            OutputStream os = conn.getOutputStream();
            BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(os, "UTF-8"));

            // writer.write(url);
            writer.flush();
            writer.flush();
            os.close();

            int responseCode = conn.getResponseCode();
            System.out.println("response code " + responseCode);

            if (responseCode == HttpURLConnection.HTTP_OK)
            {
                Toast.makeText(this, "Vehicle Deleted", Toast.LENGTH_LONG).show();
                String line;
                BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                while ((line = br.readLine()) != null)
                {
                    Response += line;
                }
                Intent Return = new Intent(VehicleDetails.this, MainActivity.class);
                VehicleDetails.this.startActivity(Return);
            }
            else
            {
                Toast.makeText(this,"error failed to delete vehicle", Toast.LENGTH_LONG).show();
                Response = " ";
            }


        }
        catch (UnsupportedEncodingException e)
        {
            e.printStackTrace();
        }
        catch (ProtocolException e)
        {
            e.printStackTrace();
        }
        catch (MalformedURLException e)
        {
            e.printStackTrace();
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
        System.out.println("response= " + Response);
        return Response;
    }



}