package uk.ac.mmu.advprog.programmingassignment2;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Map;

import javax.net.ssl.HttpsURLConnection;

public class AddVehicle extends AppCompatActivity
{
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_vehicle); //Set the view to the activity_add_vehicles.xml stored in the layout folder

        //Assign variables to the edit text boxes (INPUT BOXES)
        final EditText VehicleIDTxt = findViewById(R.id.VehicleIDTxt);
        final EditText MakeTxt = findViewById(R.id.MakeTxt);
        final EditText ModelTxt = findViewById(R.id.ModelTxt);
        final EditText YearTxt = findViewById(R.id.YearTxt);
        final EditText PriceTxt = findViewById(R.id.PriceTxt);
        final EditText LicenseNumberTxt = findViewById(R.id.LicenseNumberTxt);
        final EditText ColourTxt = findViewById(R.id.ColourTxt);
        final EditText NumberDoorsTxt = findViewById(R.id.NumberDoorsTxt);
        final EditText TransmissionTxt = findViewById(R.id.TransmissionTxt);
        final EditText MileageTxt = findViewById(R.id.MileageTxt);
        final EditText FuelTypeTxt = findViewById(R.id.FuelTypeTxt);
        final EditText EngineSizeTxt = findViewById(R.id.EngineSizeTxt);
        final EditText BodyStyleTxt = findViewById(R.id.BodyStyleTxt);
        final EditText ConditionTxt = findViewById(R.id.ConditionTxt);
        final EditText NotesTxt = findViewById(R.id.NotesTxt);

        //Find the Add button by the ID and set it to the name AddVehicleBtn
        Button AddVehicleBtn = findViewById(R.id.AddVehicleBtn);

        final HashMap<String,String> params = new HashMap<>();
        AddVehicleBtn.setOnClickListener(new View.OnClickListener()
        {
            public void onClick(View v)
            {
                //Setting the paramters to be passed through
                params.put("vehicle_id", VehicleIDTxt.getText().toString());
                params.put("make",MakeTxt.getText().toString());
                params.put("model", ModelTxt.getText().toString());
                params.put("year", YearTxt.getText().toString());
                params.put("price",PriceTxt.getText().toString());
                params.put("license_number",LicenseNumberTxt.getText().toString());
                params.put("colour",ColourTxt.getText().toString());
                params.put("number_doors",NumberDoorsTxt.getText().toString());
                params.put("transmission",TransmissionTxt.getText().toString());
                params.put("mileage",MileageTxt.getText().toString());
                params.put("fuel_type",FuelTypeTxt.getText().toString());
                params.put("engine_size",EngineSizeTxt.getText().toString());
                params.put("body_style",BodyStyleTxt.getText().toString());
                params.put("condition",ConditionTxt.getText().toString());
                params.put("notes",NotesTxt.getText().toString());

                String url = "http://10.0.2.2:8005/vehicles/api";
                PerformPostCall(url,params); //Make a put call using the url and paramaters
            }
        });
    }

    //INSERT /POST CALL
    public String PerformPostCall(String requestURL,HashMap<String,String> postDataParams)
    {
        URL url;
        String response = "";
        try
        {
            url = new URL(requestURL);

            //Create the connection object
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setReadTimeout(15000);
            conn.setConnectTimeout(15000);
            conn.setRequestMethod("POST");
            conn.setDoInput(true);
            conn.setDoOutput(true);

            //Write/send/POST dara to the connection using output stream and buffered writer
            OutputStream os = conn.getOutputStream();
            BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(os,"UTF-8"));

            //Write/send/Post key/value data (url encoded) to the server
            writer.write(getPostDataString(postDataParams));

            //clear the writer
            writer.flush();
            writer.close();

            //close the output stream
            os.close();

            //get the server response code to determine what to do next (ie success/error)
            int responseCode = conn.getResponseCode();
            System.out.println("Response code = " + responseCode);

            if (responseCode == HttpsURLConnection.HTTP_OK)
            {
                Toast.makeText(this,"Vehicle added", Toast.LENGTH_LONG).show();
                String line;
                BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                while((line=br.readLine()) != null)
                {
                    response+= line;
                }
                Intent Return = new Intent(AddVehicle.this, MainActivity.class);
                AddVehicle.this.startActivity(Return);
            }
            else
            {
               Toast.makeText(this,"Error failed to insert new Vehicle",Toast.LENGTH_LONG).show();
               response = "";
            }
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        System.out.println("response = " + response);
        return response;
    }

    //This method converts a hashmap to a URL query string of key/valuse pairs
    private String getPostDataString(HashMap<String,String> params) throws UnsupportedEncodingException
    {
        StringBuilder result = new StringBuilder();
        boolean first = true;
        for (Map.Entry<String,String> entry:params.entrySet())
        {
            if(first)
            {
                first = false;
            }
            else
            {
                result.append("&");
            }
                result.append(URLEncoder.encode(entry.getKey(), "UTF-8"));
                result.append("=");
                result.append(URLEncoder.encode(entry.getValue(), "UTF-8"));
        }
        return result.toString();
    }
}




