package uk.ac.mmu.advprog.programmingassignment2;

import java.io.Serializable;

public class Vehicle implements Serializable
{
    /**@author Rebecca Clarke 17032866
     * @version 1.0 */

    private int vehicle_id;
    private String make;
    private String model;
    private int year;
    private int price;
    private String license_number;
    private String colour;
    private int number_doors;
    private String transmission;
    private int mileage;
    private String fuel_type;
    private int engine_size;
    private String body_style;
    private String condition;
    private String notes;

    public Vehicle(int vehicle_id,String make, String model, int year, int price, String license_number, String colour, int number_doors, String transmission, int mileage, String fuel_type, int engine_size, String body_style, String condition, String notes)
    {
        this.vehicle_id = vehicle_id;
        this.make = make;
        this.model = model;
        this.year = year;
        this.price = price;
        this.license_number = license_number;
        this.colour = colour;
        this.number_doors = number_doors;
        this.transmission = transmission;
        this.mileage = mileage;
        this.fuel_type = fuel_type;
        this.engine_size = engine_size;
        this.body_style = body_style;
        this.condition = condition;
        this.notes = notes;
    }

    public int getVehicle_id()  //Get the vehicle ID - return vehicle ID
    {
        return vehicle_id;
    }

    public void setVehicle_id(int vehicle_id)  //Set the vehicle ID - return vehicle ID which is entered
    {
        this.vehicle_id = vehicle_id;
    }

    public String getMake() //Get the make - return make
    {
        return make;
    }

    public void setMake(String make) //Set the make - return make which is entered
    {
        this.make = make;
    }

    public String getModel() //Get the model - return model
    {
        return model;
    }

    public void setModel(String model) //Set the model - return model which is entered
    {
        this.model = model;
    }

    public int getYear() //Get the year - return year
    {
        return year;
    }

    public void setYear(int year) //Set the year - return year which is entered
    {
        this.year = year;
    }

    public int getPrice() //Get the price - return price
    {
        return price;
    }

    public void setPrice(int price) //Set the price - return price which is entered
    {
        this.price = price;
    }

    public String getLicense_number() //Get the License Number - return license number
    {
        return license_number;
    }

    public void setLicense_number(String license_number)  //Set the license number - return license number which is entered
    {
        this.license_number = license_number;
    }

    public String getColour() //Get the Colour - return colour
    {
        return colour;
    }

    public void setColour(String colour) //Set the colour - return colour which is entered
    {
        this.colour = colour;
    }

    public int getNumber_doors() //Get the number of doors  - return number of doors
    {
        return number_doors;
    }

    public void setNumber_doors(int number_doors) //Set the number of doors - return number of doors which is entered
    {
        this.number_doors = number_doors;
    }

    public String getTransmission() //Get the transmission  - return transmission
    {
        return transmission;
    }

    public void setTransmission(String transmission)  //Set the transmission - return transmission which is entered
    {
        this.transmission = transmission;
    }

    public int getMileage() //Get the mileage - return mileage
    {
        return mileage;
    }

    public void setMileage(int mileage)  //Set the mileage - return mileage which is entered
    {
        this.mileage = mileage;
    }

    public String getFuel_type() //Get the fuel type - return fuel type
    {
        return fuel_type;
    }

    public void setFuel_type(String fuel_type)  //Set the fuel type - return fuel type which is entered
    {
        this.fuel_type = fuel_type;
    }

    public int getEngine_size()  //Get the engine size - return engine size
    {
        return engine_size;
    }

    public void setEngine_size(int engine_size) //Set the engine size  - return engine size which is entered
    {
        this.engine_size = engine_size;
    }

    public String getBody_style() //Get the body style - return body style
    {
        return body_style;
    }

    public void setBody_style(String body_style) //Set the body style  - return body style which is entered
    {
        this.body_style = body_style;
    }

    public String getCondition() //Get the condition - return condition
    {
        return condition;
    }

    public void setCondition(String condition) //Set the condition  - return condition which is entered
    {
        this.condition = condition;
    }

    public String getNotes() //Get the notes - return notes
    {
        return notes;
    }

    public void setNotes(String notes) //Set the notes  - return notes which is entered
    {
        this.notes = notes;
    }


}
