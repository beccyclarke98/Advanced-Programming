package models;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class VehicleDAO 
{
	/**@author Rebecca Clarke
	 * @version 1.0 */
	
	private static Connection getDBConnection()
	{
		Connection connection = null;
		try
		{
			Class.forName("org.sqlite.JDBC"); //Use the sqlite package JDBC
		}
		catch(ClassNotFoundException e)
		{
			System.out.println(e.getMessage()); //If error found print out the message
		}
		
		try 
		{
			String url = "jdbc:sqlite:vehicles.sqlite"; //Use the database vehicles.sqlite
			connection = DriverManager.getConnection(url); //Get the connection
		}
		catch(SQLException e)
		{
			System.out.println(e.getMessage()); //If error found print out the message
		}
		
		return connection; //return the connection to the database
	}
	
	public ArrayList<Vehicle> getAllVehicles()
	{
		Connection dbConnection = null;
		PreparedStatement GetAllVehicles= null;
		ResultSet result = null;
		String SelectAll = "SELECT * FROM vehicles"; //SQL Command Select all from vehicle table
		
		ArrayList<Vehicle> vehicleList = new ArrayList<Vehicle>(); //Add new vehicle using the variable vehicle list 

		try
		{
			dbConnection = getDBConnection(); //get the connection to the database
			GetAllVehicles = dbConnection.prepareStatement(SelectAll); //Prepare statement using the variable with the SQL Command
			result = GetAllVehicles.executeQuery(); //execute the SQL command
			

			while(result.next()) //While result set next has informtion
			{
				int vehicle_id = result.getInt("vehicle_id"); //Get vehicle ID
				String make = result.getString("make"); //Get make
				String model = result.getString("model"); //get model
				int year = result.getInt("year"); //get year
				int price = result.getInt("price"); //get price
				String license_number = result.getString("license_number"); //get license number
				String colour = result.getString("colour"); //get colour
				int number_doors = result.getInt("number_doors"); //get number of doors
				String transmission = result.getString("transmission"); //get transmision
				int mileage = result.getInt("mileage"); //get mileage
				String fuel_type = result.getString("fuel_type"); //get fuel type
				int engine_size = result.getInt("engine_size"); //get engine size
				String body_style = result.getString("body_style"); //get body style
				String condition = result.getString("condition"); //get condition
				String notes = result.getString("notes"); //get notes
				
				
				vehicleList.add(new Vehicle(vehicle_id,make,model,year,price,license_number,colour,number_doors,transmission,mileage,fuel_type,engine_size,body_style,condition,notes));
				//add new vehicle with the variable
			}
		} 
		catch (SQLException e) 
		{
			System.out.println(e.getMessage()); //If there is a error print message
		}
		return vehicleList; //Return ArrayList
	} 
	
	public Vehicle getVehicle (int vehicle_id)
	{
		Vehicle temp = null;
		Connection dbConnection = null;
		PreparedStatement GetVehicleID= null;
		ResultSet result = null;
		String GetVehicle = "SELECT * FROM vehicles WHERE vehicle_id = " + vehicle_id + ";" ; //Select all from vehicle table where vehicle ID plus using inserted vehicle ID
		
		try
		{
			dbConnection = getDBConnection(); //get connection to the database
			GetVehicleID = dbConnection.prepareStatement(GetVehicle); //prepare statement using SQL 
			result = GetVehicleID.executeQuery(); //execute the SQL query
			
			while(result.next()) //while result set has information
			{
				int id = result.getInt("vehicle_id"); //get ID
				String make = result.getString("make"); //get make
				String model = result.getString("model"); //get model
				int year = result.getInt("year"); //get year
				int price = result.getInt("price"); //get price
				String license_number = result.getString("license_number"); //get license number
				String colour = result.getString("colour"); //get colour
				int number_doors = result.getInt("number_doors"); //get number of doors
				String transmission = result.getString("transmission"); //get transmission
				int mileage = result.getInt("mileage"); //get mileage
				String fuel_type = result.getString("fuel_type"); //get fuel type 
				int engine_size = result.getInt("engine_size"); //get engine size 
				String body_style = result.getString("body_style"); //get body style
				String condition = result.getString("condition"); //get condition
				String notes = result.getString("notes");	//get notes
			
			
			temp = new Vehicle(id,make,model,year,price,license_number,colour,number_doors,transmission,mileage,fuel_type,engine_size,body_style,condition,notes);
			//add new vehicle with the variable
		}
	} 
		catch (SQLException e) 
		{
			e.getMessage(); //if error print message
		}

		return temp; //return vehicle which is entered
	}
	
	public Boolean deleteVehicle(int vehicle_id)
	{
		Connection dbConnection = null;
		PreparedStatement DeleteVehicleID= null;
		int result = 0; //result is default false
		String DeleteVehicle = "DELETE FROM vehicles WHERE vehicle_id = " + vehicle_id + ";" ; //Delete from vehicles where the vehicle id is _ variable entered
		try
		{
			dbConnection = getDBConnection();
			try 
			{
				DeleteVehicleID = dbConnection.prepareStatement(DeleteVehicle); //prepare statement using SQL query
			} 
			catch (SQLException e) 
			{
				e.getMessage(); //If error print message
			}
			System.out.println(DeleteVehicle); //Print SQL query as text
			try 
			{
				result = DeleteVehicleID.executeUpdate(); //execute the SQL query
			} 
			catch (SQLException e) 
			{
				e.getMessage(); //if error print message
			}
		}
		finally
		{
			if(DeleteVehicleID!=null)  //if delete vehicle id is not equal to null
			{ 
				try 
				{
					DeleteVehicleID.close(); //close the SQL prepared statement
				} 
				catch (SQLException e) 
				{
					e.getMessage(); //if error print message
				} 
			}
			if(dbConnection != null)  //if connection is not null
			{ 
				try 
				{
					dbConnection.close(); //close connection
				} 
				catch (SQLException e) 
				{
					e.getMessage(); //if error print message
				} 
			}
	}
	
		if (result == 1) //if result is equal to 1 
		{	
			return true; //return true
		} 
		else //otherwise
		{
			return false; //return false
		}
		
	}
	
	public Boolean insertVehicle(Vehicle in)
	{
		Connection dbConnection = null;
		PreparedStatement InsertVehicle= null;
		String Insert = "INSERT INTO vehicles " + "VALUES ("+in.getVehicle_id()+" ,'"+in.getMake()+"', '"+in.getModel()+"', "+in.getYear()+"  , "+in.getPrice()+" , '"+in.getLicense_number()+"'"
				+ " , '"+in.getColour()+"', "+in.getNumber_doors()+", '"+in.getTransmission()+"', "+in.getMileage()+" ,"
						+ "'"+in.getFuel_type()+"' , "+in.getEngine_size()+" , '"+in.getBody_style()+"', '"+in.getCondition()+"', '"+in.getNotes()+"');";
		boolean ok = false; //setting default of inserted to false
		try
		{
			dbConnection = getDBConnection(); //get connection
			InsertVehicle = dbConnection.prepareStatement(Insert); //prepared statement insert
			System.out.println(Insert); //print out as a string sql statement
			InsertVehicle.executeUpdate(); //execute update
			ok = true; //if vehicle is inserted then set variable ok to true
		}
		catch(SQLException e)
		{
			System.out.println(e.getMessage()); //if error print message
		}

		return ok; //return ok
	}
	
	public Boolean updateVehicle(Vehicle in ,int vehicle_id) 
	{
		Connection dbConnection = null;
		PreparedStatement Update = null;

		String UpdateVehicle = "UPDATE vehicles SET vehicle_id=" + in.getVehicle_id() + ","
		+ "make='"+ in.getMake() + "' , "
		+ "model = '" + in.getModel() + "' , "
		+ "year = " + in.getYear() + ","
		+ "price = " + in.getPrice() + " , "
		+ "license_number = '" + in.getLicense_number() + "' , "
		+ "colour = '" + in.getColour() + "' , "
		+ "number_doors = " + in.getNumber_doors() + ","
		+ "transmission = '" + in.getTransmission() + "' , "
		+ "mileage = " + in.getMileage() + " ,"
		+ "fuel_type = '" + in.getFuel_type() + "' , "
		+ "engine_size = " + in.getEngine_size() + " , "
		+ "body_style = '" + in.getBody_style() + "', "
		+ "condition = '" + in.getCondition() + "',"
		+ "notes = '" + in.getNotes() + "'"
		+ "WHERE vehicle_id = " + vehicle_id ;

		//update vehicle set variable using inputed information
		
		try 
		{
			dbConnection = getDBConnection(); //get database connection
			Update = dbConnection.prepareStatement(UpdateVehicle); //prepare statement update vehicle variable
			System.out.println(UpdateVehicle); //print out as message sql statement
			Update.executeUpdate(); //execute sql update
		}
		catch (SQLException e)
		{
			System.out.println(e.getMessage()); //if error print message
			return false; //return false
		}

		return true; //if executed return true
	}
	
}