import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;

import models.Vehicle;
import models.VehicleDAO;

public class Controller 
{
	public static void main(String[] args)throws SQLException
	{
		/**@author Rebecca Clarke
		 * @version 1.0 
		 * @param input = Scanner  @return Allow the user to input numbers
		 * @param choice =  @return Reads input from the input */
		
		
		Scanner input = new Scanner(System.in);
		//Display The Menu
				System.out.println("-------------------------");
				System.out.println("Vehicle Inventory System");
				System.out.println("Choose from these options");
				System.out.println("-------------------------");
				
				System.out.println("1 - Retrieve all vehicles");
				System.out.println("2 - Search for vehicles");
				System.out.println("3 - Insert new vehicle into database");
				System.out.println("4 - Update existing vehicles details");
				System.out.println("5 - Delete vehicle from database");
				System.out.println("6 - Exit");
				
				System.out.println("Enter choice >");
				
		int choice = input.nextInt(); //Be able to input a number and it relate to a case number
		VehicleDAO dao = new VehicleDAO(); //Create new object of the VehicleDAO Class
		
		switch (choice) //Switch case for the variable choice (number you input)
		{
            case 1:ArrayList<Vehicle> allVehicles = null;
				   allVehicles = dao.getAllVehicles(); //Call the method get all vehicles from the VehicleDAO class using the object 
				   for(Vehicle v: allVehicles) //For Vehicle class and method all vehicle from the DAO
				   {
					 System.out.println("------------------------------------------------"); //Print break lines
					 System.out.println(v);  //Print out vehicle information
				   }
				   break; //Stop after this case has been carried out
			
            case 2: System.out.println("Please Insert Vehicle Id You Wish To Search For"); //Print out message
            System.out.println(dao.getVehicle(input.nextInt())); //Print out Vehicle information for ID number entered 
            break; //Stop after this case has been carried out
            
            
            case 3: System.out.println("Inserting Into Vehicle Table"); //Print out message
            insert(); //Run the method Insert
            break; //Stop after this case has been carried out
            
            case 4: System.out.println("Update"); //Print out message
            update(); //Run the method update
            break; //stop after this case has been carried out
            
            
            
            case 5: System.out.println("Please Insert Vehicle Id You Wish To Delete"); //Print out message
            		System.out.println(dao.deleteVehicle(input.nextInt())); //Run the method delete vehicle using the Input number as the ID case.
            		
            		allVehicles = dao.getAllVehicles();  //Get all vehicles
            		
    				for(Vehicle v: allVehicles)  //For Vehicle class and method all vehicle from the DAO
    				{
    					System.out.println("------------------------------------------------"); //Print break lines
    					System.out.println(v);  //Print out vehicle information
    				}
    				break; //Break
    				
            case 6: System.exit(choice); break; //Exit the application then stop the case
            
            default: System.out.println("Invalid Choice"); //Default option if no number is entered / number out of case numbers print message
		}
	}
	
	public static void insert() throws SQLException
	{
		ArrayList<Vehicle> allVehicles = new ArrayList <Vehicle>(); //Insert vehicle information as a new vehicle
		VehicleDAO dao = new VehicleDAO(); //new instance of vehicle DAO 
		Scanner input = new Scanner(System.in); //Enter information using scanner class
		
		System.out.println("Please Enter Vehicle ID"); //Print Message
		int vehicle_id = input.nextInt(); //Insert entered information into the variable
		System.out.println("Please Enter Vehicle Make"); //Print Message
		String make = input.next(); //Insert entered information into the variable
		System.out.println("Please Enter Vehicle Model"); //Print Message
		String model = input.next(); //Insert entered information into the variable
		System.out.println("Please Enter Vehicle Year"); //Print Message
		int year = input.nextInt(); //Insert entered information into the variable
		System.out.println("Please Enter Vehicle Price"); //Print Message
		int price = input.nextInt(); //Insert entered information into the variable
		System.out.println("Please Enter Vehicle License Number"); //Print Message
		String license_number = input.next(); //Insert entered information into the variable
		System.out.println("Please Enter Vehicle Colour"); //Print Message
		String colour = input.next(); //Insert entered information into the variable
		System.out.println("Please Enter Number Of Doors"); //Print Message
		int number_doors = input.nextInt(); //Insert entered information into the variable
		System.out.println("Please Enter Vehicle Transmission "); //Print Message
		String transmission = input.next(); //Insert entered information into the variable
		System.out.println("Please Enter Vehicle Mileage"); //Print Message
		int mileage = input.nextInt(); //Insert entered information into the variable
		System.out.println("Please Enter Vehicle Fuel Type"); //Print Message
		String fuel_type = input.next(); //Insert entered information into the variable
		System.out.println("Please Enter Vehicle Engine Size"); //Print Message
		int engine_size = input.nextInt(); //Insert entered information into the variable
		System.out.println("Please Enter Vehicle Body Style"); //Print Message
		String body_style = input.next(); //Insert entered information into the variable
		System.out.println("Please Enter Vehicle Condition"); //Print Message
		String condition = input.next(); //Insert entered information into the variable
		System.out.println("Please Enter Vehicle Notes"); //Print Message
		String notes = input.next(); //Insert entered information into the variable
      
        Vehicle in = new Vehicle( vehicle_id, make, model,  year,  price, license_number,  colour, 
        		number_doors,  transmission,  mileage,  fuel_type,  engine_size, 
        		 body_style,  condition,  notes); //Make a new vehicle using the variables above
        dao.insertVehicle(in); //Insert vehicle using the in scanner
        
        allVehicles = dao.getAllVehicles();  //Get all vehicles
		   for(Vehicle v: allVehicles) //For Vehicle class and method all vehicle from the DAO
		   {
			 System.out.println("------------------------------------------------"); //Print break lines
			 System.out.println(v);  //Print out vehicle information
		   }
	}

	public static void update() throws SQLException
	{
		ArrayList<Vehicle> allVehicles = new ArrayList <Vehicle>(); //Insert vehicle information as a new vehicle
		VehicleDAO dao = new VehicleDAO(); //new instance of vehicle DAO 
		Scanner input = new Scanner(System.in); //Enter information using scanner class
		
		System.out.println("Please Enter Vehicle ID You Wish To Update:" ); //Print Message
		int vehicle_id = input.nextInt(); //Insert entered information into the variable
		System.out.println("Please Enter Vehicle Make"); //Print Message
		String make = input.next(); //Insert entered information into the variable
		System.out.println("Please Enter Vehicle Model"); //Print Message
		String model = input.next(); //Insert entered information into the variable
		System.out.println("Please Enter Vehicle Year"); //Print Message
		int year = input.nextInt(); //Insert entered information into the variable
		System.out.println("Please Enter Vehicle Price"); //Print Message
		int price = input.nextInt(); //Insert entered information into the variable
		System.out.println("Please Enter Vehicle License Number"); //Print Message
		String license_number = input.next(); //Insert entered information into the variable
		System.out.println("Please Enter Vehicle Colour"); //Print Message
		String colour = input.next(); //Insert entered information into the variable
		System.out.println("Please Enter Number Of Doors"); //Print Message
		int number_doors = input.nextInt(); //Insert entered information into the variable
		System.out.println("Please Enter Vehicle Transmission "); //Print Message
		String transmission = input.next(); //Insert entered information into the variable
		System.out.println("Please Enter Vehicle Mileage"); //Print Message
		int mileage = input.nextInt();  //Insert entered information into the variable
		System.out.println("Please Enter Vehicle Fuel Type"); //Print Message
		String fuel_type = input.next(); //Insert entered information into the variable
		System.out.println("Please Enter Vehicle Engine Size"); //Print Message
		int engine_size = input.nextInt(); //Insert entered information into the variable
		System.out.println("Please Enter Vehicle Body Style"); //Print Message
		String body_style = input.next(); //Insert entered information into the variable
		System.out.println("Please Enter Vehicle Condition"); //Print Message
		String condition = input.next(); //Insert entered information into the variable
		System.out.println("Please Enter Vehicle Notes"); //Print Message
		String notes = input.next(); //Insert entered information into the variable
		
		Vehicle in = new Vehicle(vehicle_id, make, model,  year,  price, license_number,  colour, 
	        		number_doors,  transmission,  mileage,  fuel_type,  engine_size, 
	        		 body_style,  condition,  notes); //Make a new vehicle using the variables above

        dao.updateVehicle(in,vehicle_id); //Insert vehicle using the in scanner
        allVehicles = dao.getAllVehicles(); //Get all vehicles
		   for(Vehicle v: allVehicles) //For Vehicle class and method all vehicle from the DAO
		   {
			 System.out.println("------------------------------------------------"); //Print break lines
			 System.out.println(v);  //Get all vehicles
		   }
	}
}