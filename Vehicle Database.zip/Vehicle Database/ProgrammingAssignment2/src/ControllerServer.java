import org.eclipse.jetty.server.Server;
import org.eclipse.jetty.webapp.WebAppContext;
import org.eclipse.jetty.webapp.Configuration.ClassList;

public class ControllerServer 
{
	public static void main(String[] args) throws Exception 
	{
		/**@author Rebecca Clarke
		 * @version 1.0  
		 * @param server = Setting a new server to port 8005 
		 * @param WebAppContext Setting web app context using the param ctx */
		
		Server server = new Server(8005); //Set server to port 8005
		WebAppContext ctx = new WebAppContext();
		ctx.setResourceBase("webapp"); //Using the webapp folder 
		ctx.setContextPath("/vehicles"); //Default will be /vehicles 
		
		//config
		ctx.setAttribute("org.eclipse.jetty.server.webapp.ContainerIncludeJarPattern", ".*/[^/]*jstl.*\\.jar$");
		ClassList classlist = ClassList.setServerDefault(server);
		classlist.addBefore("org.eclipse.jetty.webapp.JettyWebXmlConfiguration", "org.eclipse.jetty.annotations.AnnotationConfiguration");
		
		//Mappings
		ctx.addServlet("servlets.ServletHome","/home"); // Display All Vehicle - Landing Page
		ctx.addServlet("servlets.ServletLogin", "/login"); //Display Login Page
		ctx.addServlet("servlets.ServletEdit", "/edit");  //Display EditForm Page
		ctx.addServlet("servlets.ServletDelete", "/delete"); //Use /delete after servlet ServletDelete has been run
		ctx.addServlet("servlets.ServletNewVehicle", "/new"); //Display new vehicle page
		ctx.addServlet("servlets.ServletApi","/api");
		
	//Setting the handler and starting the Server
		server.setHandler(ctx); //Set the handler to the new web app context ctx variable
		server.start(); //Start the server
		server.join(); //Join the server
	}
}