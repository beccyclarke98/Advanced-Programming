package servlets;

import java.util.ArrayList;
import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import models.Vehicle;
import models.VehicleDAO;

public class ServletEdit extends HttpServlet
{
	static final long serialVersionUID = 1L;//Universal identifier for Class
	
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException
	{
		RequestDispatcher view1 = req.getRequestDispatcher("EditForm.jsp");
		VehicleDAO dao = new VehicleDAO();
		Integer ID = Integer.parseInt(req.getParameter("edit"));
		Vehicle AllVehicles = null;
		AllVehicles = dao.getVehicle(ID);
		
		System.out.println(AllVehicles);
		req.setAttribute("vehicle", AllVehicles);
		view1.forward(req, resp);
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
	int id = Integer.parseInt(req.getParameter("id"));
	String make = req.getParameter("make");
	String model =  req.getParameter("model");
	int year = Integer.parseInt(req.getParameter("year"));
	int price = Integer.parseInt(req.getParameter("price"));
	String License_Number =  req.getParameter("license_number");
	String Colour =  req.getParameter("colour"); 
	int number_doors = Integer.parseInt(req.getParameter("number_doors"));
	String Transmission =  req.getParameter("transmission"); 
	int mileage = Integer.parseInt(req.getParameter("mileage"));
	String Fuel_Type = req.getParameter("fuel_type"); 
	int engine_size = Integer.parseInt(req.getParameter("engine_size"));
	String Body_Style =  req.getParameter("body_style"); 
	String Condition =  req.getParameter("condition"); 
	String Notes = req.getParameter("notes");
	
	VehicleDAO dao = new VehicleDAO();
	
	Vehicle in = new Vehicle(id, make, model,year,price,License_Number, Colour,number_doors,Transmission, mileage, Fuel_Type, engine_size, Body_Style,Condition, Notes );
	
	boolean done = dao.updateVehicle(in, id);
	
	if(done) 
	{
		ArrayList<Vehicle> AllVehicles = dao.getAllVehicles();
		RequestDispatcher view = req.getRequestDispatcher("ProcessingLogin.jsp");
		req.setAttribute("AllVehicles", AllVehicles);
		view.forward(req, resp);
	}
}
}
