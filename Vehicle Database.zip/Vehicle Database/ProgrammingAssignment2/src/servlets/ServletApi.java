package servlets;

//Imports
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;

import models.Vehicle;
import models.VehicleDAO;

public class ServletApi extends HttpServlet
{
	static final long serialVersionUID = 1L; //universal version identifier for the class.
	
	VehicleDAO dao = new VehicleDAO(); //New Instance of VehicleDAO class
	Gson gson = new Gson(); //New Gson Object
	PrintWriter writer; //Writer
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException,IOException
	{	
		ArrayList<Vehicle> allVehicles = dao.getAllVehicles(); //Get all the vehicles and store them in an ArrayList of type Vehicle called allVehicles
		resp.setContentType("application/json"); //Set the content type to JSON
		writer = resp.getWriter(); //Get the writer
		String vehJSON = gson.toJson(allVehicles);  //Convert all vehicle array to JSON
		writer.write(vehJSON); //Write out all vehicle array in JSON
		writer.close(); //Close the Writer
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException,IOException
	{
		writer = resp.getWriter(); //Get the writer 
		resp.setContentType("text/html;charset=UTF-8"); //Set the content type to html text
		 
		//Get the paramaters in the ( " " )
		Integer vehicle_id = Integer.parseInt(req.getParameter("vehicle_id"));
		String make = req.getParameter("make");
		String model = req.getParameter("model");
		Integer year = Integer.parseInt(req.getParameter("year"));
		Integer price = Integer.parseInt(req.getParameter("price"));
		String license_number = req.getParameter("license_number");
		String colour = req.getParameter("colour");
		Integer number_doors = Integer.parseInt(req.getParameter("number_doors"));
		String transmission = req.getParameter("transmission");
		Integer mileage = Integer.parseInt(req.getParameter("mileage"));
		String fuel_type = req.getParameter("fuel_type");
		Integer engine_size = Integer.parseInt(req.getParameter("engine_size"));
		String body_style = req.getParameter("body_style");
		String condition = req.getParameter("condition");
		String notes = req.getParameter("notes");
		
		//Insert a new vehicle
		Vehicle in = new Vehicle(vehicle_id,make,model,year,price,license_number,colour,number_doors,transmission,mileage,fuel_type,engine_size,body_style,condition,notes);
		 
		//Error checking message to check everything has been inserted correctly
		System.out.println(in.getVehicle_id() + " " + in.getMake() + " " +  in.getModel() + " "  +  in.getYear() +" " + in.getPrice() + " " + in.getLicense_number() + " " + in.getColour() + " " + in.getNumber_doors() 
		+ " " + in.getTransmission() + " " + in.getMileage() + " " + in.getFuel_type() + " " + in.getEngine_size() + " "  + in.getBody_style() + " " + in.getCondition() + " " + in.getNotes());
		
		//Insert Boolean 
		boolean inserted = false;
		inserted = dao.insertVehicle(in); //Insert using the dao statement
		
		if(inserted)
		{
			writer.write("New Vehicle Inserted");
		}
		else
		{
			writer.write("Error");
		}
		writer.close();		
	}

	@Override
	protected void doPut(HttpServletRequest req, HttpServletResponse resp) throws ServletException,IOException
	{
		
		//Get the paramaters in the ( " " )
		Integer id = Integer.parseInt(req.getParameter("vehicle_id"));
		String make = req.getParameter("make");
		String model =  req.getParameter("model");
		int year = Integer.parseInt(req.getParameter("year"));
		int price = Integer.parseInt(req.getParameter("price"));
		String License_Number =  req.getParameter("license_number");
		String Colour =  req.getParameter("colour"); 
		int number_doors = Integer.parseInt(req.getParameter("number_doors"));
		String Transmission =  req.getParameter("transmission"); 
		int mileage = Integer.parseInt(req.getParameter("mileage"));
		String Fuel_Type = req.getParameter("fuel_type"); 
		int engine_size = Integer.parseInt(req.getParameter("engine_size"));
		String Body_Style =  req.getParameter("body_style"); 
		String Condition =  req.getParameter("condition"); 
		String Notes = req.getParameter("notes");
		
		//Insert a new vehicle
		Vehicle in = new Vehicle(id, make, model,year,price,License_Number, Colour,number_doors,Transmission, mileage, Fuel_Type, engine_size, Body_Style,Condition, Notes );
		
		//Error checking message to check everything has been updated correctly
		System.out.println(in.getVehicle_id() + " " + in.getMake() + " " +  in.getModel() + " "  +  in.getYear() +" " + in.getPrice() + " " + in.getLicense_number() + " " + in.getColour() + " " + in.getNumber_doors() 
		+ " " + in.getTransmission() + " " + in.getMileage() + " " + in.getFuel_type() + " " + in.getEngine_size() + " "  + in.getBody_style() + " " + in.getCondition() + " " + in.getNotes());
		
		//Update Boolean 
		boolean update = false;
		update = dao.updateVehicle(in, id); //Update using the dao statement
		
		if(update)
		{
			writer.write("Vehicle Updated");
		}
		else
		{
			writer.write("Error");
		}
		writer.close();		
		
	
	}
		
	protected void doDelete(HttpServletRequest req, HttpServletResponse resp) throws IOException
	{
		
		writer = resp.getWriter(); //Get the writer
		
		resp.setContentType("text/html;charset=UTF-8"); //Set the content type to html text
		 
		//Get the paramaters in the ( " " )
		Integer ID = Integer.parseInt(req.getParameter("vehicle_id"));
		
		Boolean delete = false;
		
		delete = dao.deleteVehicle(ID); //if boolean done is called carry out the method delete vehicle from dao class using ID
		
		if(delete)
		{
			writer.write("Vehicle Deleted");
		}
		else
		{
			writer.write("Error");
		}
		writer.close();	//Close the writer
	}
	
}