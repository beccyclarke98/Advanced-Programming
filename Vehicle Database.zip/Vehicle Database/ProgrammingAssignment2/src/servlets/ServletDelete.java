package servlets;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import models.*;

public class ServletDelete extends HttpServlet
{
	static final long serialVersionUID = 1L; //universal version identifier for the class.

	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException,IOException
	{			
		RequestDispatcher view1 = req.getRequestDispatcher("ProcessingLogin.jsp"); //view processing login jsp
		//DELETE
		VehicleDAO dao = new VehicleDAO(); //create instance called dao of the VehicleDAO class
		Integer ID = Integer.parseInt(req.getParameter("delete")); //request parameter delete
		Boolean done = dao.deleteVehicle(ID); //if boolean done is called carry out the method delete vehicle from dao class using ID
		//view all vehicles 
		ArrayList<Vehicle> list = dao.getAllVehicles(); 
		req.setAttribute("AllVehicles", list);
		view1.forward(req, resp);
		
		
		
		
	}
}