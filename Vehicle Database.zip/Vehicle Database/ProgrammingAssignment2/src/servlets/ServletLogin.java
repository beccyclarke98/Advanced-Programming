package servlets;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import models.Vehicle;
import models.VehicleDAO;

public class ServletLogin extends HttpServlet
{
	static final long serialVersionUID = 1L; //universal version identifier for the class. 

	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException,IOException
	{
		RequestDispatcher view = req.getRequestDispatcher("login.jsp"); //do a get request from the jsp file login
		view.forward(req, resp); //view requested dispatcher on the page5
	}
	
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException,IOException
	{
		String uname = req.getParameter("username"); //get parameter called username
		String password = req.getParameter("password"); //get paramater called password 
		HttpSession sess = req.getSession(); //request get session
		if (uname.equals("admin")&& password.equals("admin")) //is the username and password entered equal "admin"
		{
			sess.setAttribute("status","loggedin"); //set the attribute of the session to logged in
			VehicleDAO dao = new VehicleDAO(); //create instance of vehicleDAO class called dao
			//view all vehicles 
			ArrayList<Vehicle> AllVehicles = dao.getAllVehicles();
			RequestDispatcher view = req.getRequestDispatcher("ProcessingLogin.jsp"); //do a post request on the processing login jsp
			req.setAttribute("AllVehicles", AllVehicles);
			view.forward(req, resp);
		}
		else 
		{
			doGet(req, resp); //Otherwise doGet request 
			
			
			
			
			
		}
		
		
		}
	}
