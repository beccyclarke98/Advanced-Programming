package servlets;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import models.Vehicle;
import models.VehicleDAO;


public class ServletNewVehicle extends HttpServlet
{
	static final long serialVersionUID = 1L; //universal version identifier for the class. 
	
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException,IOException
	{
		RequestDispatcher view = req.getRequestDispatcher("NewVehicle.jsp"); //do a get request from the jsp file NewVehicle
		view.forward(req, resp); //view requested dispatcher on the page
	}
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException,IOException
	{
		//request all the variables
		Integer vehicle_id = Integer.parseInt(req.getParameter("vehicle_id"));
		String make  = req.getParameter("make");
		String model = req.getParameter("model");
		Integer year = Integer.parseInt(req.getParameter("year"));
		Integer price = Integer.parseInt(req.getParameter("price"));
		String license_number = req.getParameter("license_number");
		String colour = req.getParameter("colour");
		Integer number_doors = Integer.parseInt(req.getParameter("number_doors"));
		String transmission = req.getParameter("transmission");
		Integer mileage = Integer.parseInt(req.getParameter("mileage"));
		String fuel_type = req.getParameter("fuel_type");
		Integer engine_size = Integer.parseInt(req.getParameter("engine_size"));
		String body_style = req.getParameter("body_style");
		String condition = req.getParameter("condition");
		String notes = req.getParameter("notes");
		
		VehicleDAO dao = new VehicleDAO(); //make a new instance of vehicleDAO class called dao
		//make a new vehicle called req1
		Vehicle req1 = new Vehicle(vehicle_id, make,model,year,price,license_number,colour,number_doors,transmission,mileage,fuel_type,engine_size,body_style,condition,notes);
		boolean done = dao.insertVehicle(req1); //insert vehicle called req1
		
		if (done) //if vehicle is inserted 
		{
			ArrayList<Vehicle> list = dao.getAllVehicles(); //get the method get all vehicle
			req.setAttribute("AllVehicles", list); //set attributes for All Vehicles to object list
			RequestDispatcher view = req.getRequestDispatcher("ProcessingLogin.jsp"); //view the processing login jsp file
			view.forward(req, resp); //view the request and response 
		}
	}
}
